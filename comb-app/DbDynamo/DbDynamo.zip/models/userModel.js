const { DynamoDBClient, PutItemCommand, QueryCommand } = require('@aws-sdk/client-dynamodb');
const { v4: uuidv4 } = require('uuid');

const client = new DynamoDBClient({ region: 'ap-south-1' }); // your DynamoDB region

class UserModel {
  static async createUser(username, password, email) {
    const userId = uuidv4();
    const params = {
      TableName: 'upes-colab', // your DynamoDB table name
      Item: {
        "userId": { S: userId },
        "username": { S: username },
        "password": { S: password },
        "email": { S: email }
      }
    };
    try {
      await client.send(new PutItemCommand(params));
      return { userId, username, email };
    } catch (error) {
      console.log('Error creating user:', error);
      throw error;
    }
  }

  static async getUserByUsername(username) {
    const params = {
      TableName: 'upes-colab',
      IndexName: 'usernameIndex',
      KeyConditionExpression: 'username = :username',
      ExpressionAttributeValues: {
        ':username': { S: username },
      },
    };
    const result = await client.send(new QueryCommand(params));
    return result.Items[0];
  }
}

module.exports = UserModel;
