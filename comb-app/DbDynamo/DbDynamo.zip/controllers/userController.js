const UserModel = require('../models/userModel');

class UserController {
  static async registerUser(req, res) {
    const { username, password, email } = req.body;
    try {
      const createdUser = await UserModel.createUser(username, password, email);
      res.status(201).json(createdUser);
    } catch (error) {
      res.status(500).json({ error: 'Error creating user' });
    }
  }

  static async loginUser(req, res) {
    const { username, password } = req.body;
    try {
      const user = await UserModel.getUserByUsername(username);
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }
      if (user.password.S !== password) {
        return res.status(401).json({ error: 'Incorrect password' });
      }
      res.status(200).json({ message: 'Login successful' });
    } catch (error) {
      console.log(error);
      res.status(500).json({ error: 'Error logging in' });
    }
  }
}

module.exports = UserController;
